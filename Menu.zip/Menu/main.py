import pygame
from pygame import mixer
import math
import przycisk
import time

pygame.init()
mixer.init()

#wielkość okna
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080
FPS=60

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
WIN = screen
pygame.display.set_caption("Gra")


clock = pygame.time.Clock()
#=======================

old_time=3600 
step_1=False
step_2=False
step_3=False
timer_download=True
best_time=0
forward=False
run2 = False

def scale_image(img, factor):
    size = round(img.get_width()*factor), round(img.get_height()*factor)
    return pygame.transform.scale(img,size)
def draw(win, images, player_car):
    for img, pos in images:
        win.blit(img, pos)
    player_car.draw(win)
    pygame.display.update()
def blit_rotate_center(win, image, top_left, angle):
    rotated_image = pygame.transform.rotate(image, angle)
    new_rect = rotated_image.get_rect(center = image.get_rect(topleft = top_left).center)
    win.blit(rotated_image, new_rect.topleft)
def move(player_car):
    keys = pygame.key.get_pressed()
    moved = False
    if keys[pygame.K_a]:
        player_car.rotate(left=True)
    if keys[pygame.K_d]:
        player_car.rotate(right=True)
    if keys[pygame.K_w]:
        moved = True
        player_car.move_forward()
    if keys[pygame.K_s]:
        moved = True
        player_car.move_backward()

    if not moved:
        player_car.reduce_speed()
#=======================
Car = 0
class Cars:
    def __init__(self,max_vel,rotation_vel):
        self.img = self.IMG
        self.max_vel = max_vel
        self.vel = 0
        self.rotation_vel = rotation_vel
        self.angle = 270
        self.x, self.y = self.START_POS
        self.acceleration = 0.5
    def rotate(self, left=False, right=False):
        if left:
            self.angle += self.rotation_vel
        elif right:
            self.angle -= self.rotation_vel
    def draw(self, win):
        blit_rotate_center(win, self.img, (self.x, self.y), self.angle)
    def move_forward(self):
        self.vel=min(self.vel+self.acceleration, self.max_vel)
        self.move()
        forward=True
    def move_backward(self):
        self.vel=max(self.vel-self.acceleration, -self.max_vel/2)
        self.move()
        forward=False
    def move (self):
        radians = math.radians(self.angle)
        vertical = math.cos(radians)*self.vel
        horizontal = math.sin(radians)*self.vel
        self.y-=vertical
        self.x-=horizontal
    def reduce_speed(self):
        self.vel = max(self.vel - self.acceleration / 2,0)
        self.move()
    def collide(self, mask):
        car_mask = pygame.mask.from_surface(self.img)
        offset = (int(self.x), int(self.y))
        poi = mask.overlap(car_mask, offset)
        return poi
    def collision(self):
        self.vel = -self.vel/2
        self.move()
class PlayerCar(Cars):
    START_POS = (800,680)
    IMG = Car

#=======================
    #=============

#ładuje zdjęcia
resume_img = pygame.image.load("images/graj.png").convert_alpha()
options_img = pygame.image.load("images/ustawienia.png").convert_alpha()
quit_img = pygame.image.load("images/wyjdz.png").convert_alpha()
audio_img = pygame.image.load('images/dzwienk.png').convert_alpha()
back_img = pygame.image.load('images/powrot.png').convert_alpha()
pojazdy_img = pygame.image.load('images/Pojazdy.png').convert_alpha()
on_img = pygame.image.load('images/on.png').convert_alpha()
off_img = pygame.image.load('images/off.png').convert_alpha()
ster_img = pygame.image.load('images/sterowanie.png').convert_alpha()
rek_img = pygame.image.load('images/rekordy.png').convert_alpha()

wsad_img = pygame.image.load('images/wsad.png').convert_alpha()

strzalka_l_img = pygame.image.load('images/strzalka_l.png').convert_alpha()
strzalka_p_img = pygame.image.load('images/strzalka_p.png').convert_alpha()
m_img = pygame.image.load('images/przy_-.png').convert_alpha()
p_img = pygame.image.load('images/przy_+.png').convert_alpha()

car1_img = pygame.image.load('images/car/car1.png').convert_alpha()
car2_img = pygame.image.load('images/car/car2.png').convert_alpha()
car3_img = pygame.image.load('images/car/car3.png').convert_alpha()
car4_img = pygame.image.load('images/car/car4.png').convert_alpha()

car1m_img = pygame.image.load('images/car/car1m.png').convert_alpha()
car2m_img = pygame.image.load('images/car/car2m.png').convert_alpha()
car3m_img = pygame.image.load('images/car/car3m.png').convert_alpha()
car4m_img = pygame.image.load('images/car/car4m.png').convert_alpha()

tlo_img = pygame.image.load('images/tlo.png').convert_alpha()
tor1m_img = pygame.image.load('images/tor1m.png').convert_alpha()
tor2m_img = pygame.image.load('images/tor2m.png').convert_alpha()
tor3m_img = pygame.image.load('images/tor3m.png').convert_alpha()
tor1_img = pygame.image.load('images/tor1.png').convert_alpha()
tor2_img = pygame.image.load('images/tor2.png').convert_alpha()
tor3_img = pygame.image.load('images/tor3.png').convert_alpha()

#tworzy przycisk
graj_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 300, resume_img, 1)
ustawienia_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 670, options_img, 1)
wyjscie_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 830, quit_img, 1)
dzwienk_przy = przycisk.Przycisk(SCREEN_WIDTH/2-250,500, audio_img, 1)
powrot_przy = przycisk.Przycisk(SCREEN_WIDTH/2,700, back_img, 1)
powrot2_przy = przycisk.Przycisk(SCREEN_WIDTH/2,900, back_img, 1)
powrot3_przy = przycisk.Przycisk(SCREEN_WIDTH/2,950, back_img, 1)
pojazdy_przy = przycisk.Przycisk(SCREEN_WIDTH/2+200, 500, pojazdy_img, 1)
on_przy = przycisk.Przycisk(SCREEN_WIDTH/2-150, 350, on_img, 1)
off_przy = przycisk.Przycisk(SCREEN_WIDTH/2+150, 350, off_img, 1)
ster_przy = przycisk.Przycisk(SCREEN_WIDTH/2+250,500, ster_img, 1)
rek_przy = przycisk.Przycisk(SCREEN_WIDTH/2-200, 500,rek_img, 1)

strz_l_przy = przycisk.Przycisk(SCREEN_WIDTH/2+300, 650,strzalka_l_img, 1)
strz_p_przy = przycisk.Przycisk(SCREEN_WIDTH/2-300, 650,strzalka_p_img, 1)
m_przy = przycisk.Przycisk(SCREEN_WIDTH/2-115, 700,m_img, 0.6)
p_przy = przycisk.Przycisk(SCREEN_WIDTH/2+115, 700,p_img, 0.6)

tor1m_przy = przycisk.Przycisk(500, 600,tor1m_img, 1)
tor2m_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 600,tor2m_img, 1)
tor3m_przy = przycisk.Przycisk(1420, 600,tor3m_img, 1)

car1_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car1_img, 0.9)
car2_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car2_img, 0.9)
car3_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car3_img, 0.9)
car4_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car4_img, 0.9)

def rysuj_tekst(text, font, text_col, x, y):  #funkcja rysująca napisy
  img = font.render(text, True, text_col)
  text = img.get_rect(center=(SCREEN_WIDTH/2+x, y))
  screen.blit(img, text)

game_paused = True
status_menu = "menu"
status_car = 1
PlayerCar.IMG = scale_image(pygame.image.load("images/car/car1.png"),0.2)
muzyka = 1
mapa = "tor"
player_car=PlayerCar(30,6)

font = pygame.font.SysFont("arialblack", 40)    #czcionka
font2 = pygame.font.SysFont("arialblack", 120)

TEXT_COL = (255, 255, 255)  #kolor
TEXT_COL2 = (0, 0, 0)  #kolor

#wyciąganie informacji z pliku
#czas3 = open('rekordy3.txt', 'r')
#cz3=czas3[:-1]
#czas3.close()

#ładowanie muzyki
a=5
i=a/10
mixer.music.load('muzyka/Music_bg.wav')
mixer.music.set_volume(i)
mixer.music.play(-1)


#pentla gry
run = True
while run:
    
  screen.blit(tlo_img, (0, 0))

  if game_paused == True:

    if status_menu == "menu":
      
      rysuj_tekst("CAR DRIVE", font2, TEXT_COL2, 5, 105)
      rysuj_tekst("CAR DRIVE", font2, TEXT_COL, 0, 100)
      if graj_przy.rysuj(screen):
        status_menu = "mapa"
      if ustawienia_przy.rysuj(screen):
        status_menu = "ustawienia"
      if wyjscie_przy.rysuj(screen):
        run = False
      if pojazdy_przy.rysuj(screen):
        status_menu = "pojazdy"
      if rek_przy.rysuj(screen):
        status_menu = 'rekordy'


    if status_menu == 'rekordy':
      
      rysuj_tekst("TWOJE REKORDY", font2, TEXT_COL2, 5, 205)
      rysuj_tekst("TWOJE REKORDY", font2, TEXT_COL, 0, 200)

      with open('rekordy1.txt', 'r') as file:
        cz1 = file.read()
      rysuj_tekst("OWAL", font, TEXT_COL2, -497, 373)
      rysuj_tekst("OWAL", font, TEXT_COL, -500, 370)
      screen.blit(tor1m_img, (SCREEN_WIDTH/2-700,400))
      rysuj_tekst(cz1+'s', font, TEXT_COL2, -497, 653)
      rysuj_tekst(cz1+'s', font, TEXT_COL, -500, 650)

      with open('rekordy2.txt', 'r') as file:
        cz2 = file.read()
      rysuj_tekst("JEZIORO", font, TEXT_COL2, 3, 373)
      rysuj_tekst("JEZIORO", font, TEXT_COL, 0, 370)
      screen.blit(tor2m_img, (SCREEN_WIDTH/2-200,400))
      rysuj_tekst(cz2+'s', font, TEXT_COL2, 3, 653)
      rysuj_tekst(cz2+'s', font, TEXT_COL, 0, 650)

      with open('rekordy3.txt', 'r') as file:
        cz3 = file.read()
      rysuj_tekst("WYBRZEŻE", font, TEXT_COL2, 503, 373)
      rysuj_tekst("WYBRZEŻE", font, TEXT_COL, 500, 370)
      screen.blit(tor3m_img, (SCREEN_WIDTH/2+300,400))
      rysuj_tekst(cz3+'s', font, TEXT_COL2, 503, 653)
      rysuj_tekst(cz3+'s', font, TEXT_COL, 500, 650)
  
      if powrot2_przy.rysuj(screen):
        status_menu = 'menu'


    if status_menu == "mapa":
      
      rysuj_tekst("WYBIERZ MAPĘ", font2, TEXT_COL2, 5, 355)
      rysuj_tekst("WYBIERZ MAPĘ", font2, TEXT_COL, 0, 350)
      if tor1m_przy.rysuj(screen):
        mapa = 'tor1_img'
        game_paused = False
      if tor2m_przy.rysuj(screen):
        mapa = 'tor2_img'
        game_paused = False
      if tor3m_przy.rysuj(screen):
        mapa = 'tor3_img'
        game_paused = False
      if powrot2_przy.rysuj(screen):
        status_menu = 'menu'

        
    if status_menu == "ustawienia":
      
      if dzwienk_przy.rysuj(screen):
        status_menu = 'muzyka'
      if ster_przy.rysuj(screen):
        status_menu = 'sterowanie'
      if powrot2_przy.rysuj(screen):
        status_menu = "menu"


    if status_menu == 'sterowanie':
      
      rysuj_tekst('STEROWANIE', font2, TEXT_COL2,3, 205)
      rysuj_tekst('STEROWANIE', font2, TEXT_COL,0, 200)

      rysuj_tekst('W - GAZ', font, TEXT_COL2,3, 353)
      rysuj_tekst('W - GAZ', font, TEXT_COL,0, 350)

      rysuj_tekst('A - SKRĘT W LEWO', font, TEXT_COL2,3, 403)
      rysuj_tekst('A - SKRĘT W LEWO', font, TEXT_COL,0, 400)

      rysuj_tekst('S - WSTECZNY', font, TEXT_COL2,3, 453)
      rysuj_tekst('S - WSTECZNY', font, TEXT_COL,0, 450)

      rysuj_tekst('D - SKRĘT W PRAWO', font, TEXT_COL2,3, 503)
      rysuj_tekst('D - SKRĘT W PRAWO', font, TEXT_COL,0, 500)

      rysuj_tekst('ESC - WYJŚCIE', font, TEXT_COL2,3, 553)
      rysuj_tekst('ESC - WYJŚCIE', font, TEXT_COL,0, 550)

      screen.blit(wsad_img, (200, 300))
      
      if powrot2_przy.rysuj(screen):
        status_menu = "ustawienia"

      
    if status_menu == "muzyka":
      
      rysuj_tekst('MUZYKA', font2, TEXT_COL2,5, 205)
      rysuj_tekst('MUZYKA', font2, TEXT_COL,0, 200)
      b = str(a)
      rysuj_tekst('GŁOŚNOŚĆ', font2, TEXT_COL2,5, 605)
      rysuj_tekst('GŁOŚNOŚĆ', font2, TEXT_COL,0, 600)
      
      rysuj_tekst((b), font2, TEXT_COL2,5, 705)
      rysuj_tekst((b), font2, TEXT_COL,0, 700)
      if m_przy.rysuj(screen):
        a=a-1
        if a<0:
          a=0
        i=a/10
        mixer.music.set_volume(i)
        
      if p_przy.rysuj(screen):
        a=a+1
        if a>10:
          a=10
        i=a/10
        mixer.music.set_volume(i)

      if on_przy.rysuj(screen):
        mixer.music.unpause()

      if off_przy.rysuj(screen):
        mixer.music.pause()
        
      if powrot2_przy.rysuj(screen):
        status_menu = "ustawienia"


    if status_menu == "pojazdy":
      
      if status_car == 1:
        IMG = scale_image(pygame.image.load("images/car/car1.png"),0.2)
        PlayerCar.IMG = scale_image(pygame.image.load("images/car/car1.png"),0.2)

        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 4
        if strz_p_przy.rysuj(screen):
          status_car = 2
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car1_przy.rysuj(screen):
          pygame.time.wait(200)
          
      if status_car == 2:
        IMG = scale_image(pygame.image.load("images/car/car2.png"),0.2)
        PlayerCar.IMG = scale_image(pygame.image.load("images/car/car2.png"),0.2)
        
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 1
        if strz_p_przy.rysuj(screen):
          status_car = 3
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car2_przy.rysuj(screen):
          pygame.time.wait(200)

      if status_car == 3:
        IMG = scale_image(pygame.image.load("images/car/car3.png"),0.2)
        PlayerCar.IMG = scale_image(pygame.image.load("images/car/car3.png"),0.2)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 2
        if strz_p_przy.rysuj(screen):
          status_car = 4
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car3_przy.rysuj(screen):
          pygame.time.wait(200)

      if status_car == 4:
        IMG = scale_image(pygame.image.load("images/car/car4.png"),0.2)
        PlayerCar.IMG = scale_image(pygame.image.load("images/car/car4.png"),0.2)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 3
        if strz_p_przy.rysuj(screen):
          status_car = 1
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car4_przy.rysuj(screen):
          pygame.time.wait(200)
        
  else:
    if mapa == 'tor1_img':
      mapa = tor1_img
      PlayerCar.START_POS = (800,680)
      player_car=PlayerCar(30,6)
      run2 = True
      Background = pygame.image.load("images/tory/tor1/tor1.png")
      Background_Mask = pygame.mask.from_surface(Background)
      Background_Grass = pygame.image.load("images/tory/tor1/trawa1.png")
      Background_Grass_Mask = pygame.mask.from_surface(Background_Grass)
      Background_Finish = pygame.image.load("images/tory/tor1/meta1.png")
      Background_Finish_Mask = pygame.mask.from_surface(Background_Finish)
      Background_Obstacles = pygame.image.load("images/tory/tor1/przeszkody1.png")
      Background_Obstacles_Mask = pygame.mask.from_surface(Background_Obstacles)

    if mapa == 'tor2_img':
      mapa = tor2_img
      PlayerCar.START_POS = (800,930)
      player_car=PlayerCar(30,6)

      run2 = True
      Background = pygame.image.load("images/tory/tor2/tor2.png")
      Background_Mask = pygame.mask.from_surface(Background)
      Background_Grass = pygame.image.load("images/tory/tor2/trawa2.png")
      Background_Grass_Mask = pygame.mask.from_surface(Background_Grass)
      Background_Finish = pygame.image.load("images/tory/tor2/meta2.png")
      Background_Finish_Mask = pygame.mask.from_surface(Background_Finish)
      Background_Obstacles = pygame.image.load("images/tory/tor2/przeszkody2.png")
      Background_Obstacles_Mask = pygame.mask.from_surface(Background_Obstacles)
      
    if mapa == 'tor3_img':
      mapa = tor3_img
      PlayerCar.START_POS = (100,230)
      player_car=PlayerCar(30,6)
      player_car.angle=180
      run2 = True
      Background = pygame.image.load("images/tory/tor3/tor3.png")
      Background_Mask = pygame.mask.from_surface(Background)
      Background_Grass = pygame.image.load("images/tory/tor3/trawa3.png")
      Background_Grass_Mask = pygame.mask.from_surface(Background_Grass)
      Background_Finish = pygame.image.load("images/tory/tor3/meta3.png")
      Background_Finish_Mask = pygame.mask.from_surface(Background_Finish)
      Background_Obstacles = pygame.image.load("images/tory/tor3/przeszkody3.png")
      Background_Obstacles_Mask = pygame.mask.from_surface(Background_Obstacles)

#========================
          #GRA
#======================== 
    rPlik = open("rekordy1.txt","r+")
    rekord1=rPlik.read()
    rPlik = open("rekordy2.txt","r+")
    rekord2=rPlik.read()
    rPlik = open("rekordy3.txt","r+")
    rekord3=rPlik.read()
    if rekord1=="":
        rPlik = open("rekordy1.txt","w")
        rPlik.write(str(3600))
    elif mapa==tor1_img:
        old_time=rekord1
    if rekord2=="":
        rPlik = open("rekordy2.txt","w")
        rPlik.write(str(3600))
    elif mapa==tor2_img:
        old_time=rekord2
    if rekord3=="":
        rPlik = open("rekordy3.txt","w")
        rPlik.write(str(3600))
    elif mapa==tor3_img:
        old_time=rekord3
    rPlik.close()
    timer=time.time()
    while run2:
        
      clock.tick(FPS)
      if timer_download:
        timer=time.time()
        timer_download=False
        
      draw(WIN, [(Background,(0,0))], player_car)
         
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          run2=False
          break
        if event.type == pygame.KEYDOWN:
          if event.key == pygame.K_ESCAPE:
            game_paused = True
            status_menu = "menu"
            run2 = False
                      
      move(player_car)

      if player_car.collide(Background_Obstacles_Mask) != None:
        player_car.collision() #kolizja_przeszkody
      if player_car.collide(Background_Grass_Mask) != None:
        if player_car.vel>10:
          player_car.vel-=1 #spowolnienie_trawa
      if player_car.x<0 or player_car.y<-50 or player_car.y>1000 or player_car.x>1900:
        player_car.collision()       
      if player_car.x>1400 and player_car.x<1850 and player_car.y>450 and player_car.y<550:
        step_1=True
      if step_1 and player_car.x>950 and player_car.x<1050 and player_car.y>0 and player_car.y<600:
        step_2=True
      if step_2 and player_car.x>100 and player_car.x<500 and player_car.y>450 and player_car.y<550:
        step_3=True
      if step_3 and player_car.collide(Background_Finish_Mask) != None:
        if mapa == tor1_img:
          best_time=time.time()-timer
          if float(old_time)>best_time:
            rPlik = open("rekordy1.txt","w")
            rPlik.write(str(round(best_time,3)))
          old_time=best_time
          rPlik.close()
          
        if mapa == tor2_img:
          best_time=time.time()-timer
          if float(old_time)>best_time:
            rPlik = open("rekordy2.txt","w")
            rPlik.write(str(round(best_time,3)))
          old_time=best_time
          rPlik.close()
          
        if mapa == tor3_img:
          best_time=time.time()-timer
          if float(old_time)>best_time:
            rPlik = open("rekordy3.txt","w")
            rPlik.write(str(round(best_time,3)))
          old_time=best_time
          rPlik.close()
          
        step_1=False
        step_2=False
        step_3=False
        timer_download=True
              
      pygame.quit

  for event in pygame.event.get():
    if event.type == pygame.KEYDOWN:
      if event.key == pygame.K_ESCAPE:
        game_paused = True
        status_menu = "menu"
    if event.type == pygame.QUIT:
      run = False

  pygame.display.update()
pygame.quit()
