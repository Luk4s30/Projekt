import pygame
from pygame import mixer
import math
import przycisk

pygame.init()
mixer.init()

#wielkość okna
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Gra")

#ładuje zdjęcia
resume_img = pygame.image.load("images/graj.png").convert_alpha()
options_img = pygame.image.load("images/ustawienia.png").convert_alpha()
quit_img = pygame.image.load("images/wyjdz.png").convert_alpha()
audio_img = pygame.image.load('images/dzwienk.png').convert_alpha()
back_img = pygame.image.load('images/powrot.png').convert_alpha()
pojazdy_img = pygame.image.load('images/Pojazdy.png').convert_alpha()
on_img = pygame.image.load('images/on.png').convert_alpha()
off_img = pygame.image.load('images/off.png').convert_alpha()
ster_img = pygame.image.load('images/sterowanie.png').convert_alpha()
rek_img = pygame.image.load('images/rekordy.png').convert_alpha()

wsad_img = pygame.image.load('images/wsad.png').convert_alpha()

strzalka_l_img = pygame.image.load('images/strzalka_l.png').convert_alpha()
strzalka_p_img = pygame.image.load('images/strzalka_p.png').convert_alpha()
m_img = pygame.image.load('images/przy_-.png').convert_alpha()
p_img = pygame.image.load('images/przy_+.png').convert_alpha()

car1_img = pygame.image.load('images/car/car1.png').convert_alpha()
car2_img = pygame.image.load('images/car/car2.png').convert_alpha()
car3_img = pygame.image.load('images/car/car3.png').convert_alpha()
car4_img = pygame.image.load('images/car/car4.png').convert_alpha()

car1m_img = pygame.image.load('images/car/car1m.png').convert_alpha()
car2m_img = pygame.image.load('images/car/car2m.png').convert_alpha()
car3m_img = pygame.image.load('images/car/car3m.png').convert_alpha()
car4m_img = pygame.image.load('images/car/car4m.png').convert_alpha()

tlo_img = pygame.image.load('images/tlo.png').convert_alpha()
tor1m_img = pygame.image.load('images/tor1m.png').convert_alpha()
tor2m_img = pygame.image.load('images/tor2m.png').convert_alpha()
tor3m_img = pygame.image.load('images/tor3m.png').convert_alpha()
tor1_img = pygame.image.load('images/tor1.png').convert_alpha()
tor2_img = pygame.image.load('images/tor2.png').convert_alpha()
tor3_img = pygame.image.load('images/tor3.png').convert_alpha()

#tworzy przycisk
graj_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 300, resume_img, 1)
ustawienia_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 670, options_img, 1)
wyjscie_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 830, quit_img, 1)
dzwienk_przy = przycisk.Przycisk(SCREEN_WIDTH/2-250,500, audio_img, 1)
powrot_przy = przycisk.Przycisk(SCREEN_WIDTH/2,700, back_img, 1)
powrot2_przy = przycisk.Przycisk(SCREEN_WIDTH/2,900, back_img, 1)
powrot3_przy = przycisk.Przycisk(SCREEN_WIDTH/2,950, back_img, 1)
pojazdy_przy = przycisk.Przycisk(SCREEN_WIDTH/2+200, 500, pojazdy_img, 1)
on_przy = przycisk.Przycisk(SCREEN_WIDTH/2-150, 350, on_img, 1)
off_przy = przycisk.Przycisk(SCREEN_WIDTH/2+150, 350, off_img, 1)
ster_przy = przycisk.Przycisk(SCREEN_WIDTH/2+250,500, ster_img, 1)
rek_przy = przycisk.Przycisk(SCREEN_WIDTH/2-200, 500,rek_img, 1)

strz_l_przy = przycisk.Przycisk(SCREEN_WIDTH/2+300, 650,strzalka_l_img, 1)
strz_p_przy = przycisk.Przycisk(SCREEN_WIDTH/2-300, 650,strzalka_p_img, 1)
m_przy = przycisk.Przycisk(SCREEN_WIDTH/2-115, 700,m_img, 0.6)
p_przy = przycisk.Przycisk(SCREEN_WIDTH/2+115, 700,p_img, 0.6)

tor1m_przy = przycisk.Przycisk(500, 600,tor1m_img, 1)
tor2m_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 600,tor2m_img, 1)
tor3m_przy = przycisk.Przycisk(1420, 600,tor3m_img, 1)

car1_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car1_img, 0.9)
car2_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car2_img, 0.9)
car3_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car3_img, 0.9)
car4_przy = przycisk.Przycisk(SCREEN_WIDTH/2, 650,car4_img, 0.9)

def rysuj_tekst(text, font, text_col, x, y):  #funkcja rysująca napisy
  img = font.render(text, True, text_col)
  text = img.get_rect(center=(SCREEN_WIDTH/2+x, y))
  screen.blit(img, text)

game_paused = True
status_menu = "menu"
status_car = 1
muzyka = 1
mapa = "tor"

font = pygame.font.SysFont("arialblack", 40)    #czcionka
font2 = pygame.font.SysFont("arialblack", 120)

TEXT_COL = (255, 255, 255)  #kolor
TEXT_COL2 = (0, 0, 0)  #kolor

#wyciąganie informacji z pliku
czas = open('czasy.txt', 'r')
czas1=czas.readline()
cz1=czas1[:-1]

czas2=czas.readline()
cz2=czas2[:-1]

czas3=czas.readline()
cz3=czas3[:-1]
czas.close()

#ładowanie muzyki
a=5
i=a/10
mixer.music.load('muzyka/Music_bg.wav')
mixer.music.set_volume(i)
mixer.music.play(-1)


#pentla gry
run = True
while run:
    
  screen.blit(tlo_img, (0, 0))

  if game_paused == True:

    if status_menu == "menu":
      
      rysuj_tekst("CAR DRIVE", font2, TEXT_COL2, 5, 105)
      rysuj_tekst("CAR DRIVE", font2, TEXT_COL, 0, 100)
      if graj_przy.rysuj(screen):
        status_menu = "mapa"
      if ustawienia_przy.rysuj(screen):
        status_menu = "ustawienia"
      if wyjscie_przy.rysuj(screen):
        run = False
      if pojazdy_przy.rysuj(screen):
        status_menu = "pojazdy"
      if rek_przy.rysuj(screen):
        status_menu = 'rekordy'


    if status_menu == 'rekordy':
      
      rysuj_tekst("TWOJE REKORDY", font2, TEXT_COL2, 5, 205)
      rysuj_tekst("TWOJE REKORDY", font2, TEXT_COL, 0, 200)

      rysuj_tekst("OWAL", font, TEXT_COL2, -497, 373)
      rysuj_tekst("OWAL", font, TEXT_COL, -500, 370)
      screen.blit(tor1m_img, (SCREEN_WIDTH/2-700,400))
      rysuj_tekst(cz1, font, TEXT_COL2, -497, 653)
      rysuj_tekst(cz1, font, TEXT_COL, -500, 650)
      
      rysuj_tekst("JEZIORO", font, TEXT_COL2, 3, 373)
      rysuj_tekst("JEZIORO", font, TEXT_COL, 0, 370)
      screen.blit(tor2m_img, (SCREEN_WIDTH/2-200,400))
      rysuj_tekst(cz2, font, TEXT_COL2, 3, 653)
      rysuj_tekst(cz2, font, TEXT_COL, 0, 650)

      rysuj_tekst("WYBRZEŻE", font, TEXT_COL2, 503, 373)
      rysuj_tekst("WYBRZEŻE", font, TEXT_COL, 500, 370)
      screen.blit(tor3m_img, (SCREEN_WIDTH/2+300,400))
      rysuj_tekst(cz3, font, TEXT_COL2, 503, 653)
      rysuj_tekst(cz3, font, TEXT_COL, 500, 650)

      if powrot2_przy.rysuj(screen):
        status_menu = 'menu'


    if status_menu == "mapa":
      
      rysuj_tekst("WYBIERZ MAPĘ", font2, TEXT_COL2, 5, 355)
      rysuj_tekst("WYBIERZ MAPĘ", font2, TEXT_COL, 0, 350)
      if tor1m_przy.rysuj(screen):
        mapa = 'tor1_img'
        game_paused = False
      if tor2m_przy.rysuj(screen):
        mapa = 'tor2_img'
        game_paused = False
      if tor3m_przy.rysuj(screen):
        mapa = 'tor3_img'
        game_paused = False
      if powrot2_przy.rysuj(screen):
        status_menu = 'menu'

        
    if status_menu == "ustawienia":
      
      if dzwienk_przy.rysuj(screen):
        status_menu = 'muzyka'
      if ster_przy.rysuj(screen):
        status_menu = 'sterowanie'
      if powrot2_przy.rysuj(screen):
        status_menu = "menu"


    if status_menu == 'sterowanie':
      
      rysuj_tekst('STEROWANIE', font2, TEXT_COL2,3, 205)
      rysuj_tekst('STEROWANIE', font2, TEXT_COL,0, 200)

      rysuj_tekst('W - GAZ', font, TEXT_COL2,3, 353)
      rysuj_tekst('W - GAZ', font, TEXT_COL,0, 350)

      rysuj_tekst('A - SKRĘT W LEWO', font, TEXT_COL2,3, 403)
      rysuj_tekst('A - SKRĘT W LEWO', font, TEXT_COL,0, 400)

      rysuj_tekst('S - WSTECZNY', font, TEXT_COL2,3, 453)
      rysuj_tekst('S - WSTECZNY', font, TEXT_COL,0, 450)

      rysuj_tekst('D - SKRĘT W PRAWO', font, TEXT_COL2,3, 503)
      rysuj_tekst('D - SKRĘT W PRAWO', font, TEXT_COL,0, 500)

      rysuj_tekst('ESC - WYJŚCIE', font, TEXT_COL2,3, 553)
      rysuj_tekst('ESC - WYJŚCIE', font, TEXT_COL,0, 550)

      screen.blit(wsad_img, (200, 300))
      
      if powrot2_przy.rysuj(screen):
        status_menu = "ustawienia"

      
    if status_menu == "muzyka":
      
      rysuj_tekst('MUZYKA', font2, TEXT_COL2,5, 205)
      rysuj_tekst('MUZYKA', font2, TEXT_COL,0, 200)
      b = str(a)
      rysuj_tekst('GŁOŚNOŚĆ', font2, TEXT_COL2,5, 605)
      rysuj_tekst('GŁOŚNOŚĆ', font2, TEXT_COL,0, 600)
      
      rysuj_tekst((b), font2, TEXT_COL2,5, 705)
      rysuj_tekst((b), font2, TEXT_COL,0, 700)
      if m_przy.rysuj(screen):
        a=a-1
        if a<0:
          a=0
        i=a/10
        mixer.music.set_volume(i)
        
      if p_przy.rysuj(screen):
        a=a+1
        if a>10:
          a=10
        i=a/10
        mixer.music.set_volume(i)

      if on_przy.rysuj(screen):
        mixer.music.unpause()

      if off_przy.rysuj(screen):
        mixer.music.pause()
        
      if powrot2_przy.rysuj(screen):
        status_menu = "ustawienia"


    if status_menu == "pojazdy":
      
      if status_car == 1:
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 4
        if strz_p_przy.rysuj(screen):
          status_car = 2
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car1_przy.rysuj(screen):
          pygame.time.wait(200)
          
      if status_car == 2:
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 1
        if strz_p_przy.rysuj(screen):
          status_car = 3
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car2_przy.rysuj(screen):
          pygame.time.wait(200)

      if status_car == 3:
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 2
        if strz_p_przy.rysuj(screen):
          status_car = 4
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car3_przy.rysuj(screen):
          pygame.time.wait(200)

      if status_car == 4:
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL2,5, 305)
        rysuj_tekst('WYBIERZ POJAZD', font2, TEXT_COL,0, 300)
        if strz_l_przy.rysuj(screen):
          status_car = 3
        if strz_p_przy.rysuj(screen):
          status_car = 1
        if powrot3_przy.rysuj(screen):
          status_menu = "menu"
        if car4_przy.rysuj(screen):
          pygame.time.wait(200)
        
  else:
    if mapa == 'tor1_img':
      mapa = tor1_img
    if mapa == 'tor2_img':
      mapa = tor2_img
    if mapa == 'tor3_img':
      mapa = tor3_img
    screen.blit((mapa), (0, 0))
    if status_car == 1:
      screen.blit(car1m_img, (500,900))
    if status_car == 2:
      screen.blit(car2m_img, (500,900))
    if status_car == 3:
      screen.blit(car3m_img, (500,900))
    if status_car == 4:
      screen.blit(car4m_img, (500,900))
    
  for event in pygame.event.get():
    if event.type == pygame.KEYDOWN:
      if event.key == pygame.K_ESCAPE:
        game_paused = True
        status_menu = "menu"
    if event.type == pygame.QUIT:
      run = False

  pygame.display.update()
pygame.quit()
