# Using readline()
file1 = open('czasy.txt', 'r')
 
i=0
for i in range(2):
    line = file1.readline()
    i=i+1
    czas1=line
    #print(line)

print(czas1)


temp = open(file1,'r').read().splitlines()
print(temp)
file1.close()
